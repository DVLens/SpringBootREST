package com.inventario.almacen.inventario_almacen_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventarioAlmacenBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventarioAlmacenBackendApplication.class, args);
	}

}
