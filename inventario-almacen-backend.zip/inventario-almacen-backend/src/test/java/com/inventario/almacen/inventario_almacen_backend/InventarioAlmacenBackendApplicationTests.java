package com.inventario.almacen.inventario_almacen_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventarioAlmacenBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
